package a2b;

public interface OmnivoreEddible {

}
